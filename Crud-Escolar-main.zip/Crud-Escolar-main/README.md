# Crud-Escolar
PPE - Sistema CRUD de cadastro escolar - (sistema básico com funcionalidades Create, Read, Update, Delete)
